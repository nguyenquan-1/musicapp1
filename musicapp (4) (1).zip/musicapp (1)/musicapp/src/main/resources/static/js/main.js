
    const audio = document.getElementById("audio");
    const title = document.getElementById("song-title");
    const artist = document.getElementById("song-artist");

    function playSong(el) {
        const url = el.dataset.audioUrl;
        const songTitle = el.dataset.title;
        const songArtist = el.dataset.artist;

        title.textContent = songTitle;
        artist.textContent = songArtist;
        audio.src = url;
        audio.play();
    }

    function togglePlay() {
        if (audio.paused) {
            audio.play();
        } else {
            audio.pause();
        }
    }

