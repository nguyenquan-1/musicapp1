package com.musicapp.musicapp.service;

import com.musicapp.musicapp.model.Artist;
import com.musicapp.musicapp.repository.ArtistRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ArtistService {
    @Autowired
    private ArtistRepository artistRepository;

    // Lấy tất cả nghệ sĩ
    public List<Artist> getAllArtists() {
        return artistRepository.findAll();
    }

    // Lấy nghệ sĩ theo ID
    public Artist getArtistById(Long id) {
        return artistRepository.findById(id).orElse(null);
    }

    // Lưu nghệ sĩ (thêm hoặc chỉnh sửa)
    public void saveArtist(Artist artist) {
        artistRepository.save(artist);
    }

    // Xóa nghệ sĩ theo ID
    public void deleteArtistById(Long id) {
        artistRepository.deleteById(id);
    }
}