package com.musicapp.musicapp.service;

import com.musicapp.musicapp.model.Genre;
import com.musicapp.musicapp.repository.GenreRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GenreService {

    @Autowired
    private GenreRepository genreRepository;

    // Lấy danh sách tất cả thể loại
    public List<Genre> getAllGenres() {
        return genreRepository.findAll();
    }

    // Lấy thể loại theo ID
    public Genre getGenreById(Long id) {
        return genreRepository.findById(id).orElse(null);
    }

    // Lưu thể loại (thêm hoặc chỉnh sửa)
    public void saveGenre(Genre genre) {
        genreRepository.save(genre);
    }

    // Xóa thể loại theo ID
    public void deleteGenreById(Long id) {
        genreRepository.deleteById(id);
    }
}