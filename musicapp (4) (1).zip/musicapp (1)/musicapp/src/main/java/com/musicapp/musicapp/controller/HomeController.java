package com.musicapp.musicapp.controller;

import com.musicapp.musicapp.repository.SongRepository;
import com.musicapp.musicapp.model.Song;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class HomeController {

    @Autowired
    private SongRepository songRepository;

    @GetMapping("/")
    public String showHomePage(Model model) {
        List<Song> songs = songRepository.findAll();
        model.addAttribute("songs", songs);
        return "index"; // Thymeleaf sẽ render file index.html
    }
}
