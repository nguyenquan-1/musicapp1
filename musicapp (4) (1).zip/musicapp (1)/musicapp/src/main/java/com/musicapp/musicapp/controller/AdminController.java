package com.musicapp.musicapp.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/admin")
public class AdminController {
   
    // Trang tổng quan dành cho admin
    @GetMapping
    public String adminDashboard(Model model) {
        model.addAttribute("title", "Admin Dashboard");
        return "admin/dashboard";
    }

    // Đã xóa phương thức manageUsers() để tránh trùng mapping

    // Điều hướng đến quản lý bài hát
    @GetMapping("/songs")
    public String manageSongs() { /* ... */ return null; }

    // Điều hướng đến quản lý nghệ sĩ
    @GetMapping("/artists")
    public String manageArtists() { /* ... */ return null; }

    // Điều hướng đến quản lý thể loại
    @GetMapping("/genres")
    public String manageGenres() { /* ... */ return null; }
}