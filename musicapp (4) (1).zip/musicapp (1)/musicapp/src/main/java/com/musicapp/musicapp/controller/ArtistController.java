package com.musicapp.musicapp.controller;

import com.musicapp.musicapp.model.Artist;
import com.musicapp.musicapp.service.ArtistService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/artists")
public class ArtistController {

    @Autowired
    private ArtistService artistService;

    // Hiển thị danh sách nghệ sĩ
    @GetMapping
    public String listArtists(Model model) {
        List<Artist> artists = artistService.getAllArtists();
        model.addAttribute("artists", artists);
        return "artist-list"; // Trỏ đến file artist-list.html
    }

    // Hiển thị chi tiết nghệ sĩ
    @GetMapping("/{id}")
    public String artistDetail(@PathVariable Long id, Model model) {
        Artist artist = artistService.getArtistById(id);
        if (artist == null) return "redirect:/artists";
        model.addAttribute("artist", artist);
        return "artist-detail"; // Trỏ đến file artist-detail.html
    }

    // Hiển thị form thêm nghệ sĩ
    @GetMapping("/add")
    public String addArtistForm(Model model) {
        model.addAttribute("artist", new Artist());
        return "artist-form"; // Trỏ đến file artist-form.html
    }

    // Xử lý thêm nghệ sĩ
    @PostMapping("/add")
    public String addArtist(@ModelAttribute Artist artist) {
        artistService.saveArtist(artist);
        return "redirect:/artists";
    }

    // Hiển thị form chỉnh sửa nghệ sĩ
    @GetMapping("/edit/{id}")
    public String editArtistForm(@PathVariable Long id, Model model) {
        Artist artist = artistService.getArtistById(id);
        if (artist == null) return "redirect:/artists";
        model.addAttribute("artist", artist);
        return "artist-form"; // Trỏ đến file artist-form.html
    }

    // Xử lý chỉnh sửa nghệ sĩ
    @PostMapping("/edit/{id}")
    public String editArtist(@PathVariable Long id, @ModelAttribute Artist artist) {
        artist.setId(id);
        artistService.saveArtist(artist);
        return "redirect:/artists";
    }

    // Xóa nghệ sĩ
    @GetMapping("/delete/{id}")
    public String deleteArtist(@PathVariable Long id) {
        artistService.deleteArtistById(id);
        return "redirect:/artists";
    }
}