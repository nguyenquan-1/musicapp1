package com.musicapp.musicapp.service;

import com.musicapp.musicapp.model.Song;
import com.musicapp.musicapp.repository.SongRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SongService {

    @Autowired
    private SongRepository songRepository;

    public List<Song> getAllSongs() {
        return songRepository.findAll();
    }

    public Song getSongById(Long id) {
        return songRepository.findById(id).orElse(null);
    }

    public void saveSong(Song song) {
        songRepository.save(song);
    }

    public void deleteSongById(Long id) {
        songRepository.deleteById(id);
    }

    // Thêm phương thức tìm kiếm bài hát
    public List<Song> searchSongs(String keyword) {
        return songRepository.searchByKeyword(keyword);
    }
}