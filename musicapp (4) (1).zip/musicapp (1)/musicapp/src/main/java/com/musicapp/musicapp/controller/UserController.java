package com.musicapp.musicapp.controller;

import com.musicapp.musicapp.TRUEMODEL.UserModel;
import com.musicapp.musicapp.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/admin/users")
public class UserController {

    @Autowired
    private UserService userService;

    // Hiển thị danh sách người dùng
    @GetMapping
    public String listUsers(Model model) {
        List<UserModel> users = userService.getAllUsers();
        model.addAttribute("users", users);
        return "admin/user-list"; // Trỏ đến file user-list.html
    }

    // Hiển thị form chỉnh sửa quyền người dùng
    @GetMapping("/edit/{id}")
    public String editUserForm(@PathVariable Long id, Model model) {
        UserModel user = userService.getUserById(id);
        if (user == null) return "redirect:/admin/users";
        model.addAttribute("user", user);
        return "admin/user-form"; // Trỏ đến file user-form.html
    }

    // Xử lý chỉnh sửa quyền người dùng
    @PostMapping("/edit/{id}")
    public String editUser(@PathVariable Long id, @RequestParam String role) {
        userService.updateUserRole(id, role);
        return "redirect:/admin/users";
    }

    // Xóa người dùng
    @GetMapping("/delete/{id}")
    public String deleteUser(@PathVariable Long id) {
        userService.deleteUserById(id);
        return "redirect:/admin/users";
    }
     }