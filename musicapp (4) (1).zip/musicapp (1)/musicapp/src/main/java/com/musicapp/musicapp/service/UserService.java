package com.musicapp.musicapp.service;

import com.musicapp.musicapp.TRUEMODEL.UserModel;
import com.musicapp.musicapp.model.User;
import com.musicapp.musicapp.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    // Lấy danh sách tất cả người dùng và chuyển đổi sang UserModel
    public List<UserModel> getAllUsers() {
        return userRepository.findAll().stream().map(user -> {
            UserModel userModel = new UserModel();
            userModel.setId(user.getId());
            userModel.setUsername(user.getUsername());
            userModel.setRole(user.getRole());
            return userModel;
        }).collect(Collectors.toList());
    }

    // Lấy người dùng theo ID và chuyển đổi sang UserModel
    public UserModel getUserById(Long id) {
        User user = userRepository.findById(id).orElse(null);
        if (user == null) return null;
        UserModel userModel = new UserModel();
        userModel.setId(user.getId());
        userModel.setUsername(user.getUsername());
        userModel.setRole(user.getRole());
        return userModel;
    }

    // Cập nhật vai trò người dùng
    public void updateUserRole(Long id, String role) {
        User user = userRepository.findById(id).orElse(null);
        if (user != null) {
            user.setRole(role);
            userRepository.save(user);
        }
    }

    // Xóa người dùng theo ID
    public void deleteUserById(Long id) {
        userRepository.deleteById(id);
    }
}