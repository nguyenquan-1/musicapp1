package com.musicapp.musicapp.controller;

import com.musicapp.musicapp.service.SongService;
import com.musicapp.musicapp.model.Song;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/songs")
// @RequestMapping("/songs") // Đường dẫn chính cho tất cả các phương thức trong controller này
public class SongController {
    @Autowired
    private SongService songService;

    // Danh sách bài hát
    @GetMapping("/")
    public String home(Model model) {
        model.addAttribute("songs", songService.getAllSongs());
        return "song-list"; // trỏ đến song-list
    }

    // Chi tiết bài hát
    @GetMapping("/{id}")
    public String songDetail(@PathVariable Long id, Model model) {
        Song song = songService.getSongById(id);
        if (song == null) return "redirect:/songs";
        model.addAttribute("song", song);
        return "song-detail";
    }
    // Tìm kiếm bài hát
    @GetMapping("/search")
    public String searchSongs(@RequestParam("keyword") String keyword, Model model) {
        model.addAttribute("songs", songService.searchSongs(keyword));
        return "index"; // Hiển thị kết quả trên trang chủ
    }

    // Quản lý bài hát (Admin Panel)

    // Hiển thị danh sách bài hát cho admin
    @GetMapping("/admin/songs")
    public String adminSongList(Model model) {
        model.addAttribute("songs", songService.getAllSongs());
        return "admin/song-list"; // trỏ đến admin/song-list.html
    }

    // Hiển thị form thêm bài hát
    @GetMapping("/admin/songs/add")
    public String addSongForm(Model model) {
        model.addAttribute("song", new Song());
        return "admin/song-form"; // trỏ đến admin/song-form.html
    }

    // Xử lý thêm bài hát
    @PostMapping("/admin/songs/add")
    public String addSong(@ModelAttribute Song song) {
        songService.saveSong(song);
        return "redirect:/admin/songs";
    }

    // Hiển thị form chỉnh sửa bài hát
    @GetMapping("/admin/songs/edit/{id}")
    public String editSongForm(@PathVariable Long id, Model model) {
        Song song = songService.getSongById(id);
        if (song == null) return "redirect:/admin/songs";
        model.addAttribute("song", song);
        return "admin/song-form"; // trỏ đến admin/song-form.html
    }

    // Xử lý chỉnh sửa bài hát
    @PostMapping("/admin/songs/edit/{id}")
    public String editSong(@PathVariable Long id, @ModelAttribute Song song) {
        song.setId(id);
        songService.saveSong(song);
        return "redirect:/admin/songs";
    }

    // Xóa bài hát
    @GetMapping("/admin/songs/delete/{id}")
    public String deleteSong(@PathVariable Long id) {
        songService.deleteSongById(id);
        return "redirect:/admin/songs";
    }
}