package com.musicapp.musicapp.TRUEMODEL;

import java.util.List;

public class ArtistModel {
    private Long id;
    private String name;
    private String bio;
    private String avatarUrl;
    private List<Long> songIds; // Danh sách ID bài hát của nghệ sĩ

    // Getter và Setter
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getBio() {
        return bio;
    }
    public void setBio(String bio) {
        this.bio = bio;
    }
    public String getAvatarUrl() {
        return avatarUrl;
    }
    public void setAvatarUrl(String avatarUrl) {
        this.avatarUrl = avatarUrl;
    }
    public List<Long> getSongIds() {
        return songIds;
    }
    public void setSongIds(List<Long> songIds) {
        this.songIds = songIds;
    }
}