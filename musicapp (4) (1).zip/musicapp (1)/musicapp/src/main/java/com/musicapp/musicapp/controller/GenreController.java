package com.musicapp.musicapp.controller;

import com.musicapp.musicapp.model.Genre;
import com.musicapp.musicapp.service.GenreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/genres")
public class GenreController {

    @Autowired
    private GenreService genreService;

    // Hiển thị danh sách thể loại
    @GetMapping
    public String listGenres(Model model) {
        List<Genre> genres = genreService.getAllGenres();
        model.addAttribute("genres", genres);
        return "genre-list"; // Trỏ đến file genre-list.html
    }

    // Hiển thị chi tiết thể loại
    @GetMapping("/{id}")
    public String genreDetail(@PathVariable Long id, Model model) {
        Genre genre = genreService.getGenreById(id);
        if (genre == null) return "redirect:/genres";
        model.addAttribute("genre", genre);
        return "genre-detail"; // Trỏ đến file genre-detail.html
    }

    // Hiển thị form thêm thể loại
    @GetMapping("/add")
    public String addGenreForm(Model model) {
        model.addAttribute("genre", new Genre());
        return "genre-form"; // Trỏ đến file genre-form.html
    }

    // Xử lý thêm thể loại
    @PostMapping("/add")
    public String addGenre(@ModelAttribute Genre genre) {
        genreService.saveGenre(genre);
        return "redirect:/genres";
    }

    // Hiển thị form chỉnh sửa thể loại
    @GetMapping("/edit/{id}")
    public String editGenreForm(@PathVariable Long id, Model model) {
        Genre genre = genreService.getGenreById(id);
        if (genre == null) return "redirect:/genres";
        model.addAttribute("genre", genre);
        return "genre-form"; // Trỏ đến file genre-form.html
    }

    // Xử lý chỉnh sửa thể loại
    @PostMapping("/edit/{id}")
    public String editGenre(@PathVariable Long id, @ModelAttribute Genre genre) {
        genre.setId(id);
        genreService.saveGenre(genre);
        return "redirect:/genres";
    }

    // Xóa thể loại
    @GetMapping("/delete/{id}")
    public String deleteGenre(@PathVariable Long id) {
        genreService.deleteGenreById(id);
        return "redirect:/genres";
    }
}